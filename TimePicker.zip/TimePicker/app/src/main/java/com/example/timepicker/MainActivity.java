package com.example.timepicker;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.Time;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {
    TimePickerDialog timePickerDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

//        TextView txt=findViewById(R.id.txt);
//        TimePicker tp=findViewById(R.id.timepicker);
//
//        tp.setIs24HourView(true);
//
//        tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
//            @Override
//            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
//                txt.setText(tp.getCurrentHour()+":"+tp.getCurrentMinute());
//
//            }
//        });


        EditText edit=findViewById(R.id.edit);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePickerDialog  = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        Time time = new Time(hourOfDay, minute, 0);
                        SimpleDateFormat sdf = new SimpleDateFormat("h:mm");
                        edit.setText(sdf.format(time));
                    }
                }, 0, 0, false);
                timePickerDialog.show();
            }
        });

    }
}
